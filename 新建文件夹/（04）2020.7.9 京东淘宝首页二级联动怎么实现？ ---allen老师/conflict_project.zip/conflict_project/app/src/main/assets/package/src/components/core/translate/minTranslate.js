export default function () {
  return (-this.snapGrid[0]);
}
