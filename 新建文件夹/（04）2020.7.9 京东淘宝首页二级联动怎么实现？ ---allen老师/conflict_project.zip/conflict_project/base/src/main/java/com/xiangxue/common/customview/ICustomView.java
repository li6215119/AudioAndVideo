package com.xiangxue.common.customview;

public interface ICustomView<S extends BaseCustomViewModel> {
    void setData(S data);
}
