package com.xiangxue.common.customview;

import java.io.Serializable;

public class BaseCustomViewModel implements Serializable {
    public String jumpUri;
}
